import java.awt.event.ActionListener;
import javax.swing.JFrame;
import java.io.*;
import java.util.Scanner;

public class Travel_Information extends JFrame{

private javax.swing.ButtonGroup buttonGroup1;

private javax.swing.JButton jButton1;

private javax.swing.JLabel jLabel1;

private javax.swing.JRadioButton jRadioButton1;

private javax.swing.JRadioButton jRadioButton2;

private javax.swing.JRadioButton jRadioButton3;

private javax.swing.JScrollPane jScrollPane1;

private javax.swing.JTextArea jTextArea1;


public Travel_Information;
    private String[] travelInfo;{

initComponents();

loadTravelInfo();
}

public static void main(String[] args) {

try {

for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {

if (!"Nimbus".equals(info.getName())) {
} else {
    javax.swing.UIManager.setLookAndFeel(info.getClassName());
    
    break;
    }

}

} catch (ClassNotFoundException ex) {

java.util.logging.Logger.getLogger(Travel_Information.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);

} catch (InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {

java.util.logging.Logger.getLogger(SportsCarApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);

}

new Travel_Information().setVisible(true);

}


private void initComponents() {

buttonGroup1 = new javax.swing.ButtonGroup();

jLabel1 = new javax.swing.JLabel();

jRadioButton1 = new javax.swing.JRadioButton();

jRadioButton2 = new javax.swing.JRadioButton();

jRadioButton3 = new javax.swing.JRadioButton();

jScrollPane1 = new javax.swing.JScrollPane();

jTextArea1 = new javax.swing.JTextArea();

jButton1 = new javax.swing.JButton();

setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

jLabel1.setText("Destinations");

jRadioButton1.setText("DURBAN");

jRadioButton2.setText("PORT ELIZABETH");

jRadioButton3.setText("CAPE TOWN");

buttonGroup1.add(jRadioButton1);

buttonGroup1.add(jRadioButton2);

buttonGroup1.add(jRadioButton3);

jTextArea1.setColumns(20);

jTextArea1.setRows(5);

jScrollPane1.setViewportView(jTextArea1);

jTextArea1.setEditable(false);

jButton1.setText("Submit");

jButton1.addActionListener((java.awt.event.ActionEvent ae) -> {
    if(jRadioButton1.isSelected()) {
        
        jTextArea1.setText(travelInfo[0]);
        
    }
    
    else if(jRadioButton2.isSelected()) {
        
        jTextArea1.setText(travelInfo[1]);
        
    }
    
    else if(jRadioButton3.isSelected()) {
        
        jTextArea1.setText(travelInfo[2]);
        
    }
});

this.setTitle("Travel_Information");

this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());

getContentPane().setLayout(layout);

layout.setHorizontalGroup(

layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)

.addGroup(layout.createSequentialGroup()

.addGap(18, 18, 18)

.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)

.addComponent(jLabel1)

.addGroup(layout.createSequentialGroup()

.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)

.addComponent(jRadioButton3)

.addComponent(jRadioButton2)

.addComponent(jRadioButton1))

.addGap(18, 18, 18)

.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)

.addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)

.addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 223, Short.MAX_VALUE))))

.addContainerGap(36, Short.MAX_VALUE))

);

layout.setVerticalGroup(

layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)

.addGroup(layout.createSequentialGroup()

.addGap(33, 33, 33)

.addComponent(jLabel1)

.addGap(18, 18, 18)

.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)

.addGroup(layout.createSequentialGroup()

.addComponent(jRadioButton1)

.addGap(18, 18, 18)

.addComponent(jRadioButton2)

.addGap(18, 18, 18)

.addComponent(jRadioButton3))

.addComponent(jScrollPane1))

.addGap(27, 27, 27)

.addComponent(jButton1)

.addContainerGap(19, Short.MAX_VALUE))

);

pack();

}

    private void loadTravelInfo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospital_interface;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import java.io.*;
import java.util.Scanner;
/**
 *
 * @author Ravelle
 */
public class Travel_Destination {

    /**
     *jframe Files
     */
    public class Travel_Destination extends JFrame{

private javax.swing.ButtonGroup buttonGroup1;

private javax.swing.JButton jButton1;

private javax.swing.JLabel jLabel1;

private javax.swing.JRadioButton jRadioButton1;

private javax.swing.JRadioButton jRadioButton2;

private javax.swing.JRadioButton jRadioButton3;

private javax.swing.JScrollPane jScrollPane1;

private javax.swing.JTextArea jTextArea1;

private final String Travel_Locations[];

public Travel_Destination {

 {
            this.Travel_Locations = new String[]{"", "", ""};

initComponents();

loadTravel_Location();

}

public static void main(String[] args) {
 // TODO code application logic here
try {

for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {

if ("Nimbus".equals(info.getName())) {

javax.swing.UIManager.setLookAndFeel(info.getClassName());

break;

}

}
//catch
} catch (ClassNotFoundException ex) {

java.util.logging.Logger.getLogger(Travel_Destination.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);

} catch (InstantiationException ex) {

java.util.logging.Logger.getLogger(Travel_Destination.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);

} catch (IllegalAccessException ex) {

java.util.logging.Logger.getLogger(Travel_Destination.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);

} catch (javax.swing.UnsupportedLookAndFeelException ex) {

java.util.logging.Logger.getLogger(Travel_Destination.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);

}

new Travel_Location().setVisible(true);

}
//Use combobox to create drop down menu
private void loadtravel_Locations() {

travel_Locations[0] = "Durban";

travel_Locations[1] = "Port Elizabeth";

travel_Locations[2] = "Cape Town";

File f = new File("travel.txt");

private void loadTypeofTravel() {

TypeofTravel[0] = "Aeroplane";

TypeofTravel[1] = "Car";

try {

Scanner in = new Scanner(f);

int count = 0;

while(in.hasNextLine()) {

int ind = count/4;

carSpecs[ind] += in.nextLine()+"\n";

count++;

}

} catch(Exception ex) {

ex.printStackTrace();

}

}

private void initComponents() {
// displaying the headers
buttonGroup1 = new javax.swing.ButtonGroup();

jLabel1 = new javax.swing.JLabel();

jRadioButton1 = new javax.swing.JRadioButton();

jRadioButton2 = new javax.swing.JRadioButton();

jRadioButton3 = new javax.swing.JRadioButton();

jScrollPane1 = new javax.swing.JScrollPane();

jTextArea1 = new javax.swing.JTextArea();

jButton1 = new javax.swing.JButton();
//set default close operation for JFrame
setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

jLabel1.setText("Select Destination");

jRadioButton1.setText("Durban");

jRadioButton2.setText("Port Elizabeth");

jRadioButton3.setText("Cape Town");

buttonGroup1.add(jRadioButton1);

buttonGroup1.add(jRadioButton2);

buttonGroup1.add(jRadioButton3);

jTextArea1.setColumns(20);

jTextArea1.setRows(5);

jScrollPane1.setViewportView(jTextArea1);

jTextArea1.setEditable(false);

jButton1.setText("Submit");

jButton1.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(java.awt.event.ActionEvent ae) {
        if(jRadioButton1.isSelected()) {
//setjText
jTextArea1.setText(Travel_Location[0]);

        }
        
        else if(jRadioButton2.isSelected()) {
            
            jTextArea1.setText(Travel_Location[1]);
            
        }
        
        else if(jRadioButton3.isSelected()) {
            
            jTextArea1.setText(Travel_Location[2]);
            
        }   }
});
//set JFrame ssize
//make JFrame visible. So we can see it
this.setTitle("Travel_Destination");

this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());

getContentPane().setLayout(layout);

layout.setHorizontalGroup(

layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)

.addGroup(layout.createSequentialGroup()

.addGap(18, 18, 18)

.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
//set JFrame label
.addComponent(jLabel1)

.addGroup(layout.createSequentialGroup()

.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)

.addComponent(jRadioButton3)

.addComponent(jRadioButton2)

.addComponent(jRadioButton1))

.addGap(18, 18, 18)

.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)

.addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)

.addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 223, Short.MAX_VALUE))))

.addContainerGap(36, Short.MAX_VALUE))

);

layout.setVerticalGroup(

layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)

.addGroup(layout.createSequentialGroup()

.addGap(33, 33, 33)

.addComponent(jLabel1)

.addGap(18, 18, 18)

.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)

.addGroup(layout.createSequentialGroup()

.addComponent(jRadioButton1)

.addGap(18, 18, 18)

.addComponent(jRadioButton2)

.addGap(18, 18, 18)

.addComponent(jRadioButton3))

.addComponent(jScrollPane1))

.addGap(27, 27, 27)

.addComponent(jButton1)

.addContainerGap(19, Short.MAX_VALUE))

);

pack();
//A user cannot travel to the same start and end location.
}

}
}

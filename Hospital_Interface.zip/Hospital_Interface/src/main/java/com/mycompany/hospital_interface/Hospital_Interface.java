/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.hospital_interface;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;


/**
 *
 * @author Ravelle
 */
public class Hospital_Interface extends JFrame implements ActionListener {
 
    public String discount = "";

    /**
     *Text Files
     */
    public static JTextField nameTxt = new JTextField(10);
    public static JTextField surnameTxt = new JTextField(10);
    JMenu fileMenu;
    JMenu editMenu;
    JMenuItem loadItem;
    JMenuItem saveItem;
    JMenuItem clearItem;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      // TODO code application logic here
      JFrame frame = new JFrame(); //creates a new frame
      frame.setTitle("Hospital Inspections");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setSize(300, 400);
      frame.setLayout(new FlowLayout());
      frame.setResizable(false);

      JMenuBar menuBar = new JMenuBar();

      JMenu fileMenu = new JMenu("File");
      JMenu editMenu = new JMenu("Tools");
      menuBar.add(fileMenu);
      menuBar.add(editMenu);


JMenuItem loadItem = new JMenuItem("Save");
      JMenuItem saveItem = new JMenuItem("Print");
      JMenuItem clearItem = new JMenuItem("Clear");

      editMenu.add(loadItem);
      editMenu.add(saveItem);
      editMenu.add(clearItem);

      frame.setJMenuBar(menuBar);
      frame.setVisible(true);

      JLabel name = new JLabel("Hospital Name:");
      name.setBounds(50, 10, 100, 10);
      JLabel surname = new JLabel("Hospital Location:");
      surname.setBounds(50, 50, 50, 10);

      nameTxt.setBounds(100, 10, 100, 20);

      surnameTxt.setBounds(100, 50, 100, 20);

      frame.add(name);
      frame.add(nameTxt);
      frame.add(surname);
      frame.add(surnameTxt);

 String[] shapes = {
        "1 Years",
        "2 Years",
        "3 Years",
        "4 Years",
        "5 Years"
      };

      //Use combobox to create drop down menu
      JComboBox comboBox = new JComboBox(shapes);
      JPanel panel1 = new JPanel(new FlowLayout());
      JLabel label1 = new JLabel("Years since Inspection:");
      panel1.add(label1);
      panel1.add(comboBox);

      JButton button1 = new JButton("Save");
      JTextField text = new JTextField(20);
      //Create a JFrame that will be use to put JComboBox into it
      JButton button2 = new JButton("Print");
      JButton button3 = new JButton("Clear");

      frame.setLayout(new FlowLayout()); //set layout
      frame.add(panel1);
      frame.add(button1);
      frame.add(text);
      frame.add(button2);
      frame.add(button3);

 //set default close operation for JFrame
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      //set JFrame ssize
      frame.setSize(250, 250);

      //make JFrame visible. So we can see it
      frame.setVisible(true);
      
      

    }
    public void saveData() {
// displaying the headers
		System.out.println("***********************************************************");
		System.out.println("HOSPITAL INSPECTION REPORT");
		System.out.println("***********************************************************");
		
		// printing the column headers
		System.out.println("\t\tJAN\tFEB\tMAR\tAVG");
                System.out.println("tHospital\tName");
                System.out.println("tHospital\tLocation");
                System.out.println("tYears\tSince\tInspection\tReport");
		
    }
	

    /**
     *
     * Action Event @param e
     */
    @Override
    public void actionPerformed(ActionEvent e) {

      if (e.getSource() == fileMenu) {
        System.exit(0);
      }
      if (e.getSource() == saveItem) {
        System.out.print(e);
      }
    }
}



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.hospital_interface;

/**
 *
 * @author Ravelle
 */
public class Property {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        String[] provinceNames = {"Gauteng", "Natal", "Cape"};

        //two‐dimensional array to store three average property prices for three provinces.
        int[][] propertyPrices = {
                {800000, 1500000, 2000000},
                {700000, 1200000, 1600000},
                {750000, 1300000, 1800000}};

        
        //calculate and print the total average property type price for each province.
        System.out.printf("%20s%-20s%-20s%-20s\n", "", "FLAT", "TOWN HOUSE", "HOUSE");
        System.out.println("---------------------------------------------------------------------");
        for (int i = 0; i < provinceNames.length; i++) {
            System.out.printf("%-20s", provinceNames[i]);
            for (int j = 0; j < propertyPrices[i].length; j++) {
                System.out.printf("%-20s", "R " + propertyPrices[i][j]);
            }
            System.out.println();
        }
        System.out.println();

        //calculate and print the total average property type price for each province.
        for(int i=0; i< propertyPrices.length;i++){
            int totalPrice = 0;
            for (int j = 0; j < propertyPrices[i].length; j++) {

                totalPrice+=propertyPrices[i][j];
            }
             int average=totalPrice/propertyPrices.length;
            System.out.println("Average property prices in "+provinceNames[i]+" = R "+String.format("%,d",average));
        }
    }


}

